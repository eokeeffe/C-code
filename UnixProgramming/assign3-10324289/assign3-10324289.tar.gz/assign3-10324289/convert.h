/*
	convert.h
	EOK
	10324289
	
	holds all the declarations for convert.c
*/
#ifndef CONVERT_H_
	#define CONVERT_H_
	#define num_steps 20
	#define column_width 12

	extern double convertxToy(double x);
	extern double convertyTox(double y);

#endif

